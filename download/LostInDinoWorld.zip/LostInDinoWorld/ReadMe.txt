//////////////////////////////////////////////////////////////////////////////

				LOST IN DINOWORLD

Authors:	R�nald Morice		Wilfried Pouchous
		Esm� James		Ayoub Al Haddan

/////////////////////////////////////////////////////////////////////////////

-----------------------------------------------------------------------------
		DEMO PROTOTYPE (PC version)
-----------------------------------------------------------------------------
1) Unzip
2) Launch LostInDinoWorld.exe
3) Controls:

----------------------
  Key    |    Action
----------------------
   A           Left
   D           Right
Space bar      Jump
   H           Attack

